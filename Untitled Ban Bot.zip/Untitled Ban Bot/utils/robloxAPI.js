const axios = require('axios');

class RobloxAPI {
    static async getUserId(username) {
        try {
            const response = await axios.post('https://users.roblox.com/v1/usernames/users', {
                usernames: [username],
                excludeBannedUsers: false
            });
            
            if (response.data.data.length > 0) {
                return response.data.data[0].id;
            }
            return null;
        } catch (error) {
            console.error('Error getting user ID:', error);
            return null;
        }
    }

    static async getUserInfo(userId) {
        try {
            const response = await axios.get(`https://users.roblox.com/v1/users/${userId}`);
            return response.data;
        } catch (error) {
            console.error('Error getting user info:', error);
            return null;
        }
    }

    static async getAvatarUrl(userId, size = '720x720') {
        try {
            const response = await axios.get(
                `https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=${size}&format=Png&isCircular=false`
            );
            return response.data.data[0]?.imageUrl || null;
        } catch (error) {
            console.error('Error getting avatar:', error);
            return null;
        }
    }

    static async getGroups(userId) {
        try {
            const response = await axios.get(`https://groups.roblox.com/v1/users/${userId}/groups/roles`);
            return response.data.data;
        } catch (error) {
            console.error('Error getting groups:', error);
            return [];
        }
    }

    static async getFriends(userId) {
        try {
            const response = await axios.get(`https://friends.roblox.com/v1/users/${userId}/friends`);
            return response.data.data;
        } catch (error) {
            console.error('Error getting friends:', error);
            return [];
        }
    }
}

module.exports = RobloxAPI;