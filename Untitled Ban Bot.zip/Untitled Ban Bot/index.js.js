const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cron = require('node-cron');
const config = require('./config.json');

// Create Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

client.commands = new Collection();
client.config = config;

// Initialize database
const db = new sqlite3.Database(config.database);
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS bans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roblox_id TEXT NOT NULL,
        roblox_username TEXT,
        discord_id TEXT,
        discord_tag TEXT,
        reason TEXT,
        banned_by TEXT,
        banned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        expires_at DATETIME,
        is_active BOOLEAN DEFAULT 1
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS ban_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT,
        roblox_id TEXT,
        roblox_username TEXT,
        discord_id TEXT,
        reason TEXT,
        duration TEXT,
        performed_by TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
});

// Load commands
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
}

// Load events
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = require(filePath);
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
    }
}

// Express server for Roblox to communicate
const app = express();
app.use(express.json());

// Verify webhook secret
app.use((req, res, next) => {
    const secret = req.headers['x-webhook-secret'];
    if (secret !== config.webhookSecret) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    next();
});

// Webhook endpoint for Roblox to check if player is banned
app.post('/api/check-ban', async (req, res) => {
    const { robloxId } = req.body;
    
    if (!robloxId) {
        return res.status(400).json({ error: 'Missing robloxId' });
    }

    db.get(
        'SELECT * FROM bans WHERE roblox_id = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > datetime("now"))',
        [robloxId],
        (err, row) => {
            if (err) {
                console.error('Database error:', err);
                return res.status(500).json({ error: 'Database error' });
            }

            if (row) {
                res.json({
                    isBanned: true,
                    reason: row.reason,
                    bannedAt: row.banned_at,
                    expiresAt: row.expires_at
                });
            } else {
                res.json({ isBanned: false });
            }
        }
    );
});

// Cron job to check for expired bans
cron.schedule('*/5 * * * *', () => {
    console.log('Checking for expired bans...');
    
    db.run(
        'UPDATE bans SET is_active = 0 WHERE is_active = 1 AND expires_at IS NOT NULL AND expires_at < datetime("now")',
        function(err) {
            if (err) {
                console.error('Error updating expired bans:', err);
            } else if (this.changes > 0) {
                console.log(`Auto-unbanned ${this.changes} expired bans`);
                
                // Log to Discord
                const logChannel = client.channels.cache.get(config.logChannelId);
                if (logChannel) {
                    logChannel.send({
                        embeds: [{
                            title: '🔄 Auto Unban',
                            description: `${this.changes} ban(s) have expired and been automatically removed.`,
                            color: 0xFFA500,
                            timestamp: new Date()
                        }]
                    });
                }
            }
        }
    );
});

app.listen(config.webhookPort, () => {
    console.log(`Webhook server running on port ${config.webhookPort}`);
});

// Login to Discord
client.login(config.token);