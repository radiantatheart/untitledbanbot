const { REST, Routes } = require('discord.js');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`✅ Logged in as ${client.user.tag}`);

        // Register slash commands
        const commands = [];
        client.commands.forEach(command => {
            commands.push(command.data.toJSON());
        });

        const rest = new REST({ version: '10' }).setToken(client.config.token);

        try {
            await rest.put(
                Routes.applicationGuildCommands(client.config.clientId, client.config.guildId),
                { body: commands }
            );
            console.log('✅ Slash commands registered');
        } catch (error) {
            console.error('Error registering commands:', error);
        }

        // Set bot status
        client.user.setActivity('Roblox Moderation', { type: 'WATCHING' });
    }
};