const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lookup')
        .setDescription('Look up a Roblox player by ID or username')
        .addStringOption(option =>
            option.setName('input')
                .setDescription('Roblox username or ID')
                .setRequired(true)),

    async execute(interaction) {
        await interaction.deferReply();

        const input = interaction.options.getString('input');
        
        try {
            let userId = input;
            let username = input;

            // If input is not numeric, try to get ID from username
            if (isNaN(input)) {
                const usernameResponse = await axios.post('https://users.roblox.com/v1/usernames/users', {
                    usernames: [input],
                    excludeBannedUsers: false
                });
                
                if (usernameResponse.data.data.length === 0) {
                    return interaction.editReply({ content: '❌ User not found.' });
                }
                
                userId = usernameResponse.data.data[0].id;
                username = usernameResponse.data.data[0].name;
            } else {
                // Get username from ID
                const userResponse = await axios.get(`https://users.roblox.com/v1/users/${userId}`);
                username = userResponse.data.name;
            }

            // Get user info
            const [userInfo, avatarInfo, groupsInfo, banStatus] = await Promise.all([
                axios.get(`https://users.roblox.com/v1/users/${userId}`),
                axios.get(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=720x720&format=Png&isCircular=false`),
                axios.get(`https://groups.roblox.com/v1/users/${userId}/groups/roles`),
                new Promise((resolve) => {
                    interaction.client.db.get(
                        'SELECT * FROM bans WHERE roblox_id = ? AND is_active = 1',
                        [userId],
                        (err, row) => resolve(row)
                    );
                })
            ]);

            const userData = userInfo.data;
            const avatarData = avatarInfo.data.data[0];
            const groupsData = groupsInfo.data.data;

            // Get ban history
            const banHistory = await new Promise((resolve) => {
                interaction.client.db.all(
                    'SELECT * FROM ban_logs WHERE roblox_id = ? ORDER BY timestamp DESC LIMIT 5',
                    [userId],
                    (err, rows) => resolve(rows || [])
                );
            });

            const embed = new EmbedBuilder()
                .setTitle(`${userData.name} (@${userData.displayName})`)
                .setDescription(`Roblox ID: \`${userId}\``)
                .setColor(banStatus ? 0xFF0000 : 0x00FF00)
                .setThumbnail(avatarData?.imageUrl || '')
                .addFields(
                    { name: '📝 Display Name', value: userData.displayName || 'None', inline: true },
                    { name: '📅 Created', value: new Date(userData.created).toLocaleDateString(), inline: true },
                    { name: '🔰 Account Age', value: `${Math.floor((Date.now() - new Date(userData.created)) / (1000 * 60 * 60 * 24))} days`, inline: true },
                    { name: '🚫 Ban Status', value: banStatus ? `Banned (${banStatus.reason})` : 'Not Banned', inline: true },
                    { name: '👥 Groups', value: groupsData.length > 0 ? groupsData.slice(0, 3).map(g => g.group.name).join(', ') : 'None', inline: false }
                );

            if (banHistory.length > 0) {
                const historyText = banHistory.map(log => 
                    `**${log.action.toUpperCase()}** - ${log.reason} (${new Date(log.timestamp).toLocaleDateString()})`
                ).join('\n');
                embed.addFields({ name: '📜 Recent History', value: historyText, inline: false });
            }

            embed.setTimestamp()
                .setFooter({ text: `Requested by ${interaction.user.tag}` });

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Lookup error:', error);
            if (error.response?.status === 404) {
                interaction.editReply({ content: '❌ User not found on Roblox.' });
            } else {
                interaction.editReply({ content: '❌ An error occurred while looking up the user.' });
            }
        }
    }
};