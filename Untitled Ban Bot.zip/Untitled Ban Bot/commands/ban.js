const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const axios = require('axios');
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a Roblox player from the game')
        .addStringOption(option =>
            option.setName('robloxid')
                .setDescription('The Roblox ID of the player')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the ban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Ban duration (e.g., 1d, 7d, 30d, permanent)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('evidence')
                .setDescription('Link to evidence (screenshot/video)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction, client) {
        await interaction.deferReply();

        // Check if user has admin role
        if (!interaction.member.roles.cache.has(config.adminRoleId)) {
            return interaction.editReply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const robloxId = interaction.options.getString('robloxid');
        const reason = interaction.options.getString('reason');
        const duration = interaction.options.getString('duration');
        const evidence = interaction.options.getString('evidence') || 'None';

        try {
            // Get Roblox user info
            const userResponse = await axios.get(`https://users.roblox.com/v1/users/${robloxId}`);
            const userData = userResponse.data;
            
            const username = userData.name;
            const displayName = userData.displayName;

            // Calculate expiration
            let expiresAt = null;
            let durationText = 'Permanent';
            
            if (duration.toLowerCase() !== 'permanent') {
                const durationMatch = duration.match(/^(\d+)([dhm])$/);
                if (durationMatch) {
                    const amount = parseInt(durationMatch[1]);
                    const unit = durationMatch[2];
                    
                    const expireDate = new Date();
                    
                    if (unit === 'd') expireDate.setDate(expireDate.getDate() + amount);
                    else if (unit === 'h') expireDate.setHours(expireDate.getHours() + amount);
                    else if (unit === 'm') expireDate.setMinutes(expireDate.getMinutes() + amount);
                    
                    expiresAt = expireDate.toISOString();
                    durationText = duration;
                } else {
                    return interaction.editReply({ content: 'Invalid duration format. Use: 1d, 7d, 30d, permanent', ephemeral: true });
                }
            }

            // Store in database
            client.db = client.db || require('sqlite3').verbose();
            
            client.db.run(
                `INSERT INTO bans (roblox_id, roblox_username, discord_id, discord_tag, reason, banned_by, expires_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [robloxId, username, interaction.user.id, interaction.user.tag, reason, interaction.user.tag, expiresAt],
                function(err) {
                    if (err) {
                        console.error('Database error:', err);
                        return interaction.editReply({ content: 'Error saving ban to database.' });
                    }

                    // Log to ban_logs
                    client.db.run(
                        `INSERT INTO ban_logs (action, roblox_id, roblox_username, discord_id, reason, duration, performed_by)
                         VALUES (?, ?, ?, ?, ?, ?, ?)`,
                        ['ban', robloxId, username, interaction.user.id, reason, durationText, interaction.user.tag]
                    );

                    // Create embed for response
                    const embed = new EmbedBuilder()
                        .setTitle('🚫 Player Banned')
                        .setColor(0xFF0000)
                        .addFields(
                            { name: 'Roblox ID', value: robloxId, inline: true },
                            { name: 'Username', value: username, inline: true },
                            { name: 'Display Name', value: displayName, inline: true },
                            { name: 'Reason', value: reason, inline: false },
                            { name: 'Duration', value: durationText, inline: true },
                            { name: 'Evidence', value: evidence, inline: true },
                            { name: 'Banned By', value: interaction.user.tag, inline: true }
                        )
                        .setThumbnail(`https://www.roblox.com/headshot-thumbnail/image?userId=${robloxId}&width=420&height=420&format=png`)
                        .setTimestamp()
                        .setFooter({ text: `Ban ID: ${this.lastID}` });

                    // Send to log channel
                    const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder(embed.data)
                            .setTitle('📋 Ban Log')
                            .setColor(0xFF4444);
                        logChannel.send({ embeds: [logEmbed] });
                    }

                    interaction.editReply({ embeds: [embed] });
                }
            );

        } catch (error) {
            console.error('Error:', error);
            if (error.response && error.response.status === 404) {
                interaction.editReply({ content: '❌ Roblox user not found. Please check the ID.' });
            } else {
                interaction.editReply({ content: '❌ An error occurred while processing the ban.' });
            }
        }
    }
};