const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Shows all available commands'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🤖 Roblox Moderation Bot Commands')
            .setColor(0x0099FF)
            .addFields(
                { name: '`/ban <robloxid> <reason> <duration> [evidence]`', value: 'Ban a Roblox player from the game', inline: false },
                { name: '`/unban <robloxid> <reason>`', value: 'Unban a Roblox player', inline: false },
                { name: '`/lookup <username/id>`', value: 'Get information about a Roblox player', inline: false },
                { name: '`/help`', value: 'Show this help message', inline: false }
            )
            .addFields(
                { name: '📝 Duration Format', value: '`1d` = 1 day\n`7d` = 7 days\n`30d` = 30 days\n`permanent` = Permanent ban', inline: false }
            )
            .setTimestamp()
            .setFooter({ text: 'Roblox Moderation Bot' });

        await interaction.reply({ embeds: [embed] });
    }
};