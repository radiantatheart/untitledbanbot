const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const axios = require('axios');
const config = require('../config.json');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unban')
        .setDescription('Unban a Roblox player from the game')
        .addStringOption(option =>
            option.setName('robloxid')
                .setDescription('The Roblox ID of the player')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the unban')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

    async execute(interaction, client) {
        await interaction.deferReply();

        // Check if user has admin role
        if (!interaction.member.roles.cache.has(config.adminRoleId)) {
            return interaction.editReply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const robloxId = interaction.options.getString('robloxid');
        const reason = interaction.options.getString('reason');

        try {
            // Get Roblox user info
            const userResponse = await axios.get(`https://users.roblox.com/v1/users/${robloxId}`);
            const userData = userResponse.data;
            
            const username = userData.name;
            const displayName = userData.displayName;

            // Check if player is currently banned
            client.db.get(
                'SELECT * FROM bans WHERE roblox_id = ? AND is_active = 1',
                [robloxId],
                async (err, row) => {
                    if (err) {
                        console.error('Database error:', err);
                        return interaction.editReply({ content: 'Error checking ban status.' });
                    }

                    if (!row) {
                        return interaction.editReply({ content: '❌ This player is not currently banned.' });
                    }

                    // Update ban record
                    client.db.run(
                        'UPDATE bans SET is_active = 0 WHERE roblox_id = ? AND is_active = 1',
                        [robloxId]
                    );

                    // Log to ban_logs
                    client.db.run(
                        `INSERT INTO ban_logs (action, roblox_id, roblox_username, discord_id, reason, performed_by)
                         VALUES (?, ?, ?, ?, ?, ?)`,
                        ['unban', robloxId, username, interaction.user.id, reason, interaction.user.tag]
                    );

                    // Create embed
                    const embed = new EmbedBuilder()
                        .setTitle('✅ Player Unbanned')
                        .setColor(0x00FF00)
                        .addFields(
                            { name: 'Roblox ID', value: robloxId, inline: true },
                            { name: 'Username', value: username, inline: true },
                            { name: 'Display Name', value: displayName, inline: true },
                            { name: 'Reason', value: reason, inline: false },
                            { name: 'Unbanned By', value: interaction.user.tag, inline: true },
                            { name: 'Originally Banned', value: row.banned_at || 'Unknown', inline: true }
                        )
                        .setThumbnail(`https://www.roblox.com/headshot-thumbnail/image?userId=${robloxId}&width=420&height=420&format=png`)
                        .setTimestamp();

                    // Send to log channel
                    const logChannel = interaction.guild.channels.cache.get(config.logChannelId);
                    if (logChannel) {
                        const logEmbed = new EmbedBuilder(embed.data)
                            .setTitle('📋 Unban Log')
                            .setColor(0x44FF44);
                        logChannel.send({ embeds: [logEmbed] });
                    }

                    interaction.editReply({ embeds: [embed] });
                }
            );

        } catch (error) {
            console.error('Error:', error);
            if (error.response && error.response.status === 404) {
                interaction.editReply({ content: '❌ Roblox user not found. Please check the ID.' });
            } else {
                interaction.editReply({ content: '❌ An error occurred while processing the unban.' });
            }
        }
    }
};